package com.example.macpas.ui;

import java.util.Timer;
import java.util.TimerTask;

public class TimerCycle {
    private int time;

    public TimerCycle(int time){
        Timer timer = new Timer();
    }
    public void testing(){
        System.out.println("Hello People of the World!");

    }
}

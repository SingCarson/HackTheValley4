package com.example.macpas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Locale;

public class ABCD extends AppCompatActivity {
    private TextView subdisplay;

    private Button A;
    private Button B;
    private Button C;
    private Button D;
    private Button cancel;
    private TextToSpeech mTTS;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_abcd);

        Bundle extras = getIntent().getExtras();
        String value = "";
        if (extras != null) {
            value = extras.getString("display");
        }
        subdisplay = (TextView) findViewById(R.id.textView2);
        subdisplay.setText(value);

        A = (Button) findViewById(R.id.button6);
        B = (Button) findViewById(R.id.button5);
        C = (Button) findViewById(R.id.button4);
        D = (Button) findViewById(R.id.button3);
        cancel = (Button) findViewById(R.id.button8);

        mTTS = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    int result = mTTS.setLanguage(Locale.ENGLISH);

                    if (result == TextToSpeech.LANG_MISSING_DATA
                            || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        Log.e("TTS", "Language not supported");
                    } else {
                    }
                } else {
                    Log.e("TTS", "Initialization failed");
                }
            }
        });

        A.setFocusableInTouchMode(true);
        A.requestFocus();

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMain();
            }
        });

        A.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str = subdisplay.getText().toString();
                str += "A";
                subdisplay.setText(str);
                mTTS.shutdown();
                openMain();
            }
        });

        A.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(final View v, boolean hasFocus) {
                if(hasFocus){
                    final Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            A.setBackgroundResource(android.R.drawable.btn_default);
                            A.setTextColor(Color.BLACK);
                            v.clearFocus();
                            B.setFocusableInTouchMode(true);
                            B.requestFocus();
                            B.setBackgroundColor(Color.BLACK);
                            B.setTextColor(Color.WHITE);
                            A.setFocusableInTouchMode(false);
                            String text = A.getText().toString();
                            mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);
                        }
                    }, 2000);

                }
            }
        });

        B.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str = subdisplay.getText().toString();
                str += "B";
                subdisplay.setText(str);
                mTTS.shutdown();
                openMain();
            }
        });

        B.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(final View v, boolean hasFocus) {
                if(hasFocus){
                    final Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            B.setBackgroundResource(android.R.drawable.btn_default);
                            B.setTextColor(Color.BLACK);
                            v.clearFocus();
                            C.setFocusableInTouchMode(true);
                            C.requestFocus();
                            C.setBackgroundColor(Color.BLACK);
                            C.setTextColor(Color.WHITE);
                            B.setFocusableInTouchMode(false);
                            String text = A.getText().toString();
                            mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);
                        }
                    }, 2000);

                }
            }
        });

        C.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str = subdisplay.getText().toString();
                str += "C";
                subdisplay.setText(str);
                mTTS.shutdown();
                openMain();
            }
        });

        C.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(final View v, boolean hasFocus) {
                if(hasFocus){
                    final Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            C.setBackgroundResource(android.R.drawable.btn_default);
                            C.setTextColor(Color.BLACK);
                            v.clearFocus();
                            D.setFocusableInTouchMode(true);
                            D.requestFocus();
                            D.setBackgroundColor(Color.BLACK);
                            D.setTextColor(Color.WHITE);
                            C.setFocusableInTouchMode(false);
                            String text = A.getText().toString();
                            mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);
                        }
                    }, 2000);

                }
            }
        });

        D.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str = subdisplay.getText().toString();
                str += "D";
                subdisplay.setText(str);
                mTTS.shutdown();
                openMain();
            }
        });

        D.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(final View v, boolean hasFocus) {
                if(hasFocus){
                    final Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            D.setBackgroundResource(android.R.drawable.btn_default);
                            D.setTextColor(Color.BLACK);
                            v.clearFocus();
                            A.setFocusableInTouchMode(true);
                            A.requestFocus();
                            A.setBackgroundColor(Color.BLACK);
                            A.setTextColor(Color.WHITE);
                            D.setFocusableInTouchMode(false);
                            String text = A.getText().toString();
                            mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);
                        }
                    }, 2000);

                }
            }
        });

    }

    public void openMain() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("subdisplay",subdisplay.getText());
        startActivity(intent);
    }


}
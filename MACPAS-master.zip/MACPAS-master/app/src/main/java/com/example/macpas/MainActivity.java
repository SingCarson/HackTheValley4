package com.example.macpas;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import android.os.Handler;
import android.os.SystemClock;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.navigation.NavigationView;

import androidx.drawerlayout.widget.DrawerLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.Menu;
import android.widget.Button;
import android.widget.TextView;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private Button buttTest;
    private Button buttonABCD;
    private Button buttonEFGH;
    private Button buttonIJKLMN;
    private Button buttonOPQRST;
    private Button buttonUVWXYZ;
    private Button backspace;
    private Button space;
    private Button clear;
    private Button speak;
    private TextToSpeech mTTS;
    private TextView display;
    private AppBarConfiguration mAppBarConfiguration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Testing out the button
        buttTest = findViewById(R.id.button10);
        buttTest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buttonABCD.setBackgroundColor(Color.BLACK);
                buttonABCD.setTextColor(Color.WHITE);
                buttonABCD.setFocusableInTouchMode(true);
                buttonABCD.requestFocus();
                String text = buttonABCD.getText().toString();
                mTTS.speak("Ay B C D", TextToSpeech.QUEUE_FLUSH, null);

            }
        });

        buttonABCD = findViewById(R.id.button24);
        buttonABCD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.clearFocus();
                openABCD();
                mTTS.shutdown();
            }
        });

        buttonABCD.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(final View v, boolean hasFocus) {
                if(hasFocus){
                    final Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            buttonABCD.setBackgroundResource(android.R.drawable.btn_default);
                            buttonABCD.setTextColor(Color.BLACK);
                            v.clearFocus();
                            buttonEFGH.setFocusableInTouchMode(true);
                            buttonEFGH.requestFocus();
                            buttonEFGH.setBackgroundColor(Color.BLACK);
                            buttonEFGH.setTextColor(Color.WHITE);
                            buttonABCD.setFocusableInTouchMode(false);
                            String text = buttonEFGH.getText().toString();
                            mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);
                        }
                    }, 2000);

                }
            }
        });


        buttonEFGH = findViewById(R.id.button25);
        buttonEFGH.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.clearFocus();
                openEFGH();
                mTTS.shutdown();
            }
        });

        buttonEFGH.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(final View v, boolean hasFocus) {

                if(hasFocus){
                    final Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            buttonEFGH.setBackgroundResource(android.R.drawable.btn_default);
                            buttonEFGH.setTextColor(Color.BLACK);
                            v.clearFocus();
                            buttonIJKLMN.setFocusableInTouchMode(true);
                            buttonIJKLMN.requestFocus();
                            buttonIJKLMN.setBackgroundColor(Color.BLACK);
                            buttonIJKLMN.setTextColor(Color.WHITE);
                            buttonEFGH.setFocusableInTouchMode(false);
                            String text = buttonIJKLMN.getText().toString();
                            mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);
                        }
                    }, 2000);

                }
            }
        });


        buttonIJKLMN = findViewById(R.id.button26);
        buttonIJKLMN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.clearFocus();
                openIJKLMN();
                mTTS.shutdown();
            }
        });

        buttonIJKLMN.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(final View v, boolean hasFocus) {

                if(hasFocus){
                    final Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            buttonIJKLMN.setBackgroundResource(android.R.drawable.btn_default);
                            buttonIJKLMN.setTextColor(Color.BLACK);
                            v.clearFocus();
                            buttonOPQRST.setFocusableInTouchMode(true);
                            buttonOPQRST.requestFocus();
                            buttonOPQRST.setBackgroundColor(Color.BLACK);
                            buttonOPQRST.setTextColor(Color.WHITE);
                            buttonIJKLMN.setFocusableInTouchMode(false);
                            String text = buttonOPQRST.getText().toString();
                            mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);
                        }
                    }, 2000);

                }
            }
        });

        buttonOPQRST = findViewById(R.id.button27);
        buttonOPQRST.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.clearFocus();
                openOPQRST();
                mTTS.shutdown();
            }
        });

        buttonOPQRST.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(final View v, boolean hasFocus) {

                if(hasFocus){
                    final Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            buttonOPQRST.setBackgroundResource(android.R.drawable.btn_default);
                            buttonOPQRST.setTextColor(Color.BLACK);
                            v.clearFocus();
                            buttonUVWXYZ.setFocusableInTouchMode(true);
                            buttonUVWXYZ.requestFocus();
                            buttonUVWXYZ.setBackgroundColor(Color.BLACK);
                            buttonUVWXYZ.setTextColor(Color.WHITE);
                            buttonOPQRST.setFocusableInTouchMode(false);
                            String text = buttonUVWXYZ.getText().toString();
                            mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);
                        }
                    }, 2000);

                }
            }
        });

        buttonUVWXYZ = findViewById(R.id.button28);
        buttonUVWXYZ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.clearFocus();
                openUVWXYZ();
                mTTS.shutdown();
            }
        });

        buttonUVWXYZ.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(final View v, boolean hasFocus) {

                if(hasFocus){
                    final Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            buttonUVWXYZ.setBackgroundResource(android.R.drawable.btn_default);
                            buttonUVWXYZ.setTextColor(Color.BLACK);
                            v.clearFocus();
                            clear.setFocusableInTouchMode(true);
                            clear.requestFocus();
                            clear.setBackgroundColor(Color.BLACK);
                            clear.setTextColor(Color.WHITE);
                            buttonUVWXYZ.setFocusableInTouchMode(false);
                            String text = clear.getText().toString();
                            mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);
                        }
                    }, 2000);

                }
            }
        });

        backspace = findViewById(R.id.button22);

        space = findViewById(R.id.button23);
        display = findViewById(R.id.textView4);

        Bundle extras = getIntent().getExtras();
        String value = "";
        if (extras != null) {
            value = extras.getString("subdisplay");
        }
        display.setText(value);

        space.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str = display.getText().toString();
                if (str.length() >= 1) {
                    str += " ";
                    display.setText(str);
                }
            }
        });

        space.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(final View v, boolean hasFocus) {

                if(hasFocus){
                    final Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            space.setBackgroundResource(android.R.drawable.btn_default);
                            space.setTextColor(Color.BLACK);
                            v.clearFocus();
                            buttonABCD.setFocusableInTouchMode(true);
                            buttonABCD.requestFocus();
                            buttonABCD.setBackgroundColor(Color.BLACK);
                            buttonABCD.setTextColor(Color.WHITE);
                            space.setFocusableInTouchMode(false);
                            String text = buttonABCD.getText().toString();
                            mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);
                        }
                    }, 2000);

                }
            }
        });

        backspace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str = display.getText().toString();
                if (str.length() >= 1) {
                    str = str.substring(0, str.length() - 1);
                    display.setText(str);
                }
                //mTTS.shutdown();
            }
        });

        backspace.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(final View v, boolean hasFocus) {

                if(hasFocus){
                    final Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            backspace.setBackgroundResource(android.R.drawable.btn_default);
                            backspace.setTextColor(Color.BLACK);
                            v.clearFocus();
                            space.setFocusableInTouchMode(true);
                            space.requestFocus();
                            space.setBackgroundColor(Color.BLACK);
                            space.setTextColor(Color.WHITE);
                            backspace.setFocusableInTouchMode(false);
                            String text = space.getText().toString();
                            mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);
                        }
                    }, 2000);

                }
            }
        });

        clear = findViewById(R.id.button20);
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str = display.getText().toString();
                if (str.length() >= 1) {
                    str = "";
                    display.setText(str);
                }
                //mTTS.shutdown();
            }
        });

        clear.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(final View v, boolean hasFocus) {

                if(hasFocus){
                    final Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            clear.setBackgroundResource(android.R.drawable.btn_default);
                            clear.setTextColor(Color.BLACK);
                            v.clearFocus();
                            speak.setFocusableInTouchMode(true);
                            speak.requestFocus();
                            speak.setBackgroundColor(Color.BLACK);
                            speak.setTextColor(Color.WHITE);
                            clear.setFocusableInTouchMode(false);
                            String text = speak.getText().toString();
                            mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);
                        }
                    }, 2000);

                }
            }
        });

        speak = findViewById(R.id.button21);
        mTTS = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    int result = mTTS.setLanguage(Locale.ENGLISH);

                    if (result == TextToSpeech.LANG_MISSING_DATA
                            || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        Log.e("TTS", "Language not supported");
                    } else {
                        speak.setEnabled(true);
                    }
                } else {
                    Log.e("TTS", "Initialization failed");
                }
            }
        });

        speak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = display.getText().toString();
                mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);
                //mTTS.shutdown();
            }
        });

        speak.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {

                if(hasFocus){
                    final Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            speak.setBackgroundResource(android.R.drawable.btn_default);
                            speak.setTextColor(Color.BLACK);
                            speak.clearFocus();
                            backspace.setFocusableInTouchMode(true);
                            backspace.requestFocus();
                            backspace.setBackgroundColor(Color.BLACK);
                            backspace.setTextColor(Color.WHITE);
                            speak.setFocusableInTouchMode(false);
                            String text = backspace.getText().toString();
                            mTTS.speak("backspace", TextToSpeech.QUEUE_FLUSH, null);
                        }
                    }, 2000);

                }
            }
        });

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_gallery, R.id.nav_slideshow,
                R.id.nav_tools, R.id.nav_share, R.id.nav_send)
                .setDrawerLayout(drawer)
                .build();
    }

    public void openABCD() {
        buttonABCD.requestFocus();
        Intent intent = new Intent(this, ABCD.class);
        intent.putExtra("display",display.getText());
        startActivity(intent);
    }

    public void openEFGH() {
        Intent intent = new Intent(this, EFGH.class);
        intent.putExtra("display",display.getText());
        startActivity(intent);
    }

    public void openIJKLMN() {
        Intent intent = new Intent(this, IJKLMN.class);
        intent.putExtra("display",display.getText());
        startActivity(intent);
    }

    public void openOPQRST() {
        Intent intent = new Intent(this, OPQRST.class);
        intent.putExtra("display",display.getText());
        startActivity(intent);
    }

    public void openUVWXYZ() {
        Intent intent = new Intent(this, UVWXYZ.class);
        intent.putExtra("display",display.getText());
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
}

# MACPAS
An android app to help patients in need who struggle with ALS using partner assisted scanning. On the press of a button, the app scans through sets of letters. After the assistant receives an indication from the ALS patient to select a button (ie. with the blink of an eye), the app then allows the patient to select the desired letter using the scanning method again. The purpose of this app is to draw on the manual aspects of partner assisted scanning but in the form of an app. The app also includes features such as text to speech and letter correction.
# Inspiration
To help patients in need who struggle with ALS.

# What it does
On the press of a button, the app scans through sets of letters. After the assistant receives an indication from the ALS patient to select a button (ie. with the blink of an eye), the app then allows the patient to select the desired letter using the scanning method again. The purpose of this app is to draw on the manual aspects of partner assisted scanning but in the form of an app. The app also includes features such as text to speech and letter correction.

# How we built it
Android Studio and Java

# Challenges we ran into
Learning the new environment for developing android apps was a challenge at first but we easily overcame with the help of online tutorials and experimenting.

# Accomplishments that we're proud of
We were not only able to learn Android Studio in less than 48 hours, but we also created a functional app that meets the requirements given by Hotel Dieu Shaver.

# What we learned
As part of learning Andoird development, we learned about user experience, and design.

# What's next for MACPAS
There are many future improvements in store such the addition of accounts, tutorial, device setup, and more.
